%
% Copyright (c) 2021, Tharaj Thaj, Emanuele Viterbo, and  Yi Hong, Monash University
% All rights reserved.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are met:
%
% 1. Redistributions of source code must retain the above copyright notice, this
%   list of conditions and the following disclaimer.
% 2. Redistributions in binary form must reproduce the above copyright notice,
%   this list of conditions and the following disclaimer in the documentation
%   and/or other materials provided with the distribution.
% 3. The reference [R1] and [R2] should be cited if the codes are used for
%   publication.
%
%THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
%ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
%WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
%DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
%ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
%(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
%LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
%ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
%(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
%SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
%
%    - Latest version of this code may be downloaded from: https://ecse.monash.edu/staff/eviterbo/
%    - Freely distributed for educational and research purposes

% [R1]. T. Thaj, E. Viterbo and Y. Hong, "Orthogonal Time Sequency Multiplexing Modulation: Analysis and Low-Complexity Receiver Design," in IEEE Transactions on Wireless Communications, doi: 10.1109/TWC.2021.3088479.
% [R2]. T. Thaj and E. Viterbo, "Orthogonal Time Sequency Multiplexing Modulation," 2021 IEEE Wireless Communications and Networking Conference (WCNC), 2021, pp. 1-7, doi: 10.1109/WCNC49053.2021.9417451.



function [est_bits,ite,x_data] = Matched_Filter_GS_detector(N,M,M_mod,no,data_grid,Y,H_tf,n_ite,omega,Tn_block_matrix,Gn_block_matrix,zn_block_vector,r,Wn,decision)
%% Initial assignments
%Number of symbols per frame
N_syms_perfram=sum(sum((data_grid>0)));
%Arranging the delay-Doppler grid symbols into an array
data_array=reshape(data_grid,1,N*M);
%finding position of data symbols in the array
[~,data_index]=find(data_array>0);
M_bits=log2(M_mod);
N_bits_perfram = N_syms_perfram*M_bits;
%% initial time-frequency low complexity estimate assuming ideal pulses
if(1)
    Y_tf=fft((Y*Wn)).'; % ISFFT                                              %% equation (18) in [R2]
    X_tf=conj(H_tf).*Y_tf./(H_tf.*conj(H_tf)+no); % single tap equalizer     %% equation (19) in [R2]
    X_est = ifft(X_tf.')*Wn; % SFFT                                          %% equation (21) in [R2]
    X_est=qammod(qamdemod(X_est,M_mod,'gray'),M_mod,'gray');
    X_est=X_est.*data_grid;
    X_tilda_est=X_est*Wn;
end
X_tilda_est=X_tilda_est.*data_grid;

%% Matched Filter Gauss Siedel algorithm
error=zeros(n_ite);
Y_tilda_est=zeros(M,N);
Y_tilda=reshape(r,M,N);
x_soft=zeros(M,N);

for ite=1:n_ite
    for i=1:N
        Tn=Tn_block_matrix(:,:,i);
        zn=zn_block_vector(:,i);
        sn_prev=X_tilda_est(:,i);
        sn_next=-Tn*sn_prev+zn;     %equation (47) in [R1] (or equivalently equation (27) in [R2])
        x_soft(:,i)=sn_next.*data_grid(:,i);
        X_tilda_est(:,i)=(x_soft(:,i));        
    end
    if(decision==1)
        x_m=x_soft*Wn;
        X_tilda_est=(1-omega)*X_tilda_est+omega*((qammod(qamdemod(x_m,M_mod,'gray'),M_mod,'gray').*data_grid)*Wn);  %equation (50) in [R1] (or equivalently equation (27) in [R2])
    end    
    for i=1:N
        Gn=Gn_block_matrix(:,:,i);
        Y_tilda_est(1:M,i)=Gn*(X_tilda_est(1:M,i));
    end
    error(ite)=sum(sum(abs(Y_tilda_est-Y_tilda).^2))./N_syms_perfram;
    if(ite>1)
        if(error(ite)>=error(ite-1))
            break;
        end
    end    
end
if(n_ite==0)
    ite=0;
end
%% detector output likelihood calculations for turbo decode
X_est=X_tilda_est*Wn;
x_est=reshape(X_est,1,N*M);
x_data=x_est(data_index);
est_bits=reshape(qamdemod(x_data,M_mod,'gray','OutputType','bit'),N_bits_perfram,1);

end

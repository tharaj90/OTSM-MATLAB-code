%
% Copyright (c) 2021, Tharaj Thaj, Emanuele Viterbo, and  Yi Hong, Monash University
% All rights reserved.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are met:
%
% 1. Redistributions of source code must retain the above copyright notice, this
%   list of conditions and the following disclaimer.
% 2. Redistributions in binary form must reproduce the above copyright notice,
%   this list of conditions and the following disclaimer in the documentation
%   and/or other materials provided with the distribution.
% 3. The reference [R1] and [R2] should be cited if the codes are used for
%   publication.
%
%THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
%ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
%WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
%DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
%ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
%(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
%LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
%ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
%(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
%SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
%
%    - Latest version of this code may be downloaded from: https://ecse.monash.edu/staff/eviterbo/
%    - Freely distributed for educational and research purposes

% [R1]. T. Thaj, E. Viterbo and Y. Hong, "Orthogonal Time Sequency Multiplexing Modulation: Analysis and Low-Complexity Receiver Design," in IEEE Transactions on Wireless Communications, doi: 10.1109/TWC.2021.3088479.
% [R2]. T. Thaj and E. Viterbo, "Orthogonal Time Sequency Multiplexing Modulation," 2021 IEEE Wireless Communications and Networking Conference (WCNC), 2021, pp. 1-7, doi: 10.1109/WCNC49053.2021.9417451.



function [chan_coef,delay_taps,Doppler_taps,taps]=Generate_delay_Doppler_channel_parameters(N,M,car_fre,delta_f,T,max_speed)
one_delay_tap = 1/(M*delta_f);
one_doppler_tap = 1/(N*T);

%delays = [0 30 70 90 110 190 410]*10^(-9);%EPA model 
delays = [0 30 150 310 370 710 1090 1730 2510]*10^(-9);%EVA model
% delays = [0 50 120 200 230 500 1600 2300 5000]*10^(-9);%ETU model


taps = length(delays);% number of delay taps
delay_taps = round(delays/one_delay_tap);%assuming no fraction for the delay

%pdp = [0 -1.0 -2.0 -3.0 -8.0 -17.2 -20.8];% EPA power delay profile
pdp = [0 -1.5 -1.4 -3.6 -0.6 -9.1 -7.0 -12.0 -16.9];% EVA power delay profile
%pdp = [-1 -1 -1 0 0 0  -3 -5 -7];% ETU power delay profile


pow_prof = 10.^(pdp/10);
pow_prof = pow_prof/sum(pow_prof);%normalization of power delay profile
chan_coef = sqrt(pow_prof).*(sqrt(1/2) * (randn(1,taps)+1i*randn(1,taps)));%channel coef. for each path
max_UE_speed = max_speed*(1000/3600);
Doppler_vel = (max_UE_speed*car_fre)/(299792458);
max_Doppler_tap = Doppler_vel/one_doppler_tap;
Doppler_taps = (max_Doppler_tap*cos(2*pi*rand(1,taps)));%Doppler taps using Jake's spectrum
end